
while(True):
    c = input("Enter a integer: ")

    if ('A'<=c<='z' or float(c)%1 !=0 ):
        print("Error: Try again")
    else:
        print("The integer is: ", c)
        break
