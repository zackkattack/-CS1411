admin_pass = "as1987Jantu35*^ft$TTTdyuHi28Mary"

attempt = 0
while(True):
    guest_pass = input("Enter yout password: ")


    if guest_pass == admin_pass:
        print ("\nYou have successfully logged in to the server as an admin")
        break
#Checks if the password is wrong and gives user a hent
    elif (guest_pass != admin_pass):
        attempt += 1
        if attempt == 1:
            print ("The length of your password is", len(admin_pass),"\n")
        if attempt == 2:
            count = 0
            for i in admin_pass:
                if '0'<=i<='9':
                    count += 1
            print ("Your password includes", count, "number letters\n")
        if attempt == 3:
            count = 0
            for i in admin_pass:
                if i=='i':
                    count += 1
            print ("Your password incluedes", count, "'i's\n")
        if attempt == 4:
            print ("\nYou had too many password attempts. You are forever "
            ,"banded from this terminal.")
            break
