admin_pass1 ="as1987Jantu35*^ft$TTTdyuHi28Mary" # Admin password
admin_pass2 ="Hello55IR1988tr$$st" # Second admin pasword
attempt =0  # Number of password attempts


while(True):
    guest_pass = input("\nEnter yout password: ")

    if guest_pass == admin_pass1 or guest_pass == admin_pass2: # Checks if the guest password is right
        print ("\nYou have successfully logged in to the server as an admin")
        break
    elif guest_pass != admin_pass1 or guest_pass != admin_pass2: # Checks if the gurst password is wrong 
        attempt +=1
        print("The entered password was wrong. That was your ", attempt ,"ith try. Please try again" )
