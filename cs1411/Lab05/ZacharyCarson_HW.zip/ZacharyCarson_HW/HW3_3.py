print("Melting and Boiling points of Alkanes")
print("Name\tMelting Point (deg C)\t\tBoiling Point (deg C)")

print("Methane\t-162\t\t\t\t-183")
print("Ethane\t-89\t\t\t\t-172")
print("Propane\t-42\t\t\t\t-188")
print("Brutane\t-0.5\t\t\t\t-135")
