#Name:Zachary Carson
#Course:CS 1411
#Date:2-9-2017
#
#
#Problem:
#Write a Python program that asks users to input an integer number and
#print the summation of its digits and total number of its digits.
#( i.e. for n=35, sum is 3+5=8, and total number of digits is 2)
#
#Given:
#n1 + n2+ n3 = total of digits
#
#Analysis
#Input:Whole numbe rinteger
#Outputs: digits of number intered added up
#
#
#Method/Algorithm:
#Step 1: Start
#Step 2: Get number
#Step 3: Final number = 0
#Step 4: remainder of number = number%10
#Step 5: final number = final numebr + remainder
#Step 6: number = (number-remainder)/10
#Step 7: if(number > 0) Goto 4
#Step 8: Print Final number
#Step 9: End
#
#TestCases:
#Input:5506403
#Expected OutPut:5+5+0+6+4+0+3: 23
#
#Input:234
#Expected Output:2+3+4: 9
#Write a comment about passing Testing results
#Sucessful test
#Program:


number = int(input("Enter a number:"))
final = 0

while number > 0:
    remainder = number%10
    final += remainder
    number=(number-remainder)/10

print (final)
