#Name:Zachary Carson
#Course:CS 1411
#Date:2-18-2017
#
#
#Problem:#Write a Python program that takes as input a month and year (as integer numbers)
#and determines the number of days in the month, and prints them to the
#output. Thirty day sare in September, April, June, and November. All the
#rest are 31 except for February which could be 28 or 29 depending upon whether
#the year is a
#leap year or not. Consider a year a leap year if it is evenly divisible by 4.
#
#Given:
#Setember,April, November, June has 30 days
#February is 28 or 29 days depending on if is a leap year
#leapyears are divisible by 4
#the rest of the monts are 30 days
#
#Analysis
#Input:year and month (integer)
#Outputs:number of days in that month
#
#
#Method/Algorithm:
#Step 1: Start
#Step 2: Get year
#Step 3: Get month
#Step 4: if (month ==4 or month ==6 or month ==9 or month ==11) Print 30 days
#Step 5: elif(month == 2) if(year%4 == 0) print "29 days" else print "28 days"
#Step 6: else Print 31 days
#Step 7: End
#
#
#TestCases:
#Input:2008, 2
#Expected OutPut: 31 days
#
#Input:1245, 9
#Expected Output:30 days
#Write a comment about passing Testing results
#Successful test
#Program:


year = input("What year is it?: ")
month = input("What month is it?: ")

if (month ==4 or month ==6 or month ==9 or month ==11):
    print ("30 days")
elif(month == 2):
    if(year%4 == 0):
        print ("29 days")
    else:
        print ("28 days")
else:
    print ("31 days")
