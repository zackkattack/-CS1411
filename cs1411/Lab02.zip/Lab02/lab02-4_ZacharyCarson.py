#Name:Zachary Carson
#Course:CS 1411
#Date:2-8-2017
#
#
#Problem:Write a simple calculator python program that prints the following menu:
#1. Addition
#2. Subtraction
#3. Multiplication
#4. Division
#5. Quit
#That takes as input the number of desired operations and 2 numbers and outputs
#the calculation result. After printing each calculation result the program must
#reshow the operations menu and ask user if she/he wants to choose another
#operation or quit
#
#Given:
#Addition = num1 + num2
#Subtraction = num1 - num2
#Multiplication = num1 * num2
#Division = num1 / num2
#
#Analysis
#Input: Ooperation, 2 numbers that are going to be operated on
#Outputs: Operations prefromed on the two numbers
#
#
#Method/Algorithm:
#Step 1: Start
#Step 2: running = True
#Step 3: Print operation menu
#Step 4: Get N
#Step 5: if (N=1) Get num1, num2; print num1+num2
#Step 6: if (N=2) Get num1, num2; print num1-num2
#Step 7: if (N=3) Get num1, num2; print num1*num2
#Step 8: if (N=4) Get num1, num2; print num1/num2
#Step 9: if (N=5)
#Step 10: if (running == true) Goto step 3
#Step 11: End
#
#
#TestCases:
#Input:1;2;4
#Expected OutPut:
#Zach's Calculator v1.1

#1.Addition
#2.Subtraction
#3.Multiplication
#4.Division
#5.Quit
#
#Enter the number of the operation you would like to preform:1
#Enter your first number:2
#Enter your second number:4
#
#Your answer is:  6.0
#
#
#Input:4;3.45;.334
#Expected Output:
#Zach's Calculator v1.1
#
#1.Addition
#2.Subtraction
#3.Multiplication
#4.Division
#5.Quit
#
#Enter the number of the operation you would like to preform:4
#Enter your first number:3.45
#Enter your second number:.334
#
#Your answer is:  10.3293413174

#Write a comment about passing Testing results
#Both test passed without flaws
#Program:


running = True

while(running):

    print ("Zach's Calculator v1.1")
    print ("\n1.Addition")
    print ("2.Subtraction")
    print ("3.Multiplication")
    print ("4.Division")
    print ("5.Quit\n")

    menu_Number = int(input("\nEnter the number of the operation you would like to preform:"))

    if(menu_Number == 1):
        number_1 = float(input("Enter your first number:"))
        number_2 = float(input("Enter your second number:"))

        print ("\nYour answer is: ", number_1 + number_2)
    elif(menu_Number == 2):
        number_1 = float(input("Enter your first number:"))
        number_2 = float(input("Enter your second number:"))

        print ("\nYour answer is: ", number_1 - number_2)
    elif(menu_Number == 3):
        number_1 = float(input("Enter your first number:"))
        number_2 = float(input("Enter your second number:"))

        print ("\nYour answer is: ", number_1 * number_2)
    elif(menu_Number == 4):
        number_1 = float(input("Enter your first number:"))
        number_2 = float(input("Enter your second number:"))

        print ("\nYour answer is: ", number_1 / number_2)
    if(menu_Number == 5):
        running = False
