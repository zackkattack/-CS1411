#Name:Zachary Carson
#Course:CS 1411
#Date:2-18-2017
#
#
#Problem:
#Write a Python program that asks users to input 10 float numbers
#(using a while statement), and print the minimum number.
#
#Given:
#None
#
#
#Analysis
#Input:10 random float numbers
#Outputs:The smallest number of the 10 numbers
#
#
#Method/Algorithm:
#Step 1: Start
#Step 2: numbers_of_input = 1
#Step 3: first_number = 0
#Step 4: input a second_number
#Step 5: if(number_1 == 1) first_number = second_number
#Step 6: if(second_number < first_number) first_number = second_number
#Step 7: numbers_of_input = numbers_of_input + 1
#Step 8: if(numbers_of_input <=10) Goto 3
#Step 9: pritn first_number
#Step 10: End
#
#
#
#TestCases:
#Input:9, 8, 7, 6, 5, 4, 3, 3, 2, 2, 1, -1
#Expected OutPut:-1
#
#Input:2,1.99, 22,30.23, 99,24.67, 33.23,44,53,10
#Expected Output:1.99
#Write a comment about passing Testing results
#Both test cases were sucessful
#Program:


numbers_of_input = 1
first_number = 0

while(numbers_of_input <= 10):

    second_number = float(input("Enter a float number :"))
    if(numbers_of_input ==1):
        first_number = second_number


    if(second_number < first_number):
        first_number = second_number

    numbers_of_input += 1

print ("the lowest number is: ", first_number)
