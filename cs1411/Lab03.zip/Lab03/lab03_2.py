#Name:Zachary Carson
#Course:CS 1411
#Date:
#
#
#Problem:
#Write a program which gets a natural number n, and classifies the range of
#numbers (natural numbers less that n), with respect to perfect, abundant
#or deficient.
#
#Given:
#A abundant number is a number that the summation of the preceding numbers is greater then the actual number
##A abundant number is a number that the summation of the preceding numbers is less than then the actual number
#A perfect number is a number that the summation of the preceding numbers is equal then the actual number
#
#Analysis
#Input:n
#Outputs: Weather or not the numbers befor n is abundant, deficient, or perfect
#
#
#Method/Algorithm:
#Step 1:Start
#Step 2:Input n
#Step 3:i = 1
#Step 4:k = 1
#Step 5:sum_of_factors = 0
#Step 6:if(i%k==0) sum_of_factors += k
#Step 7:if(k < i) Goto 6
#Step 8:if (sum_of_factors == i): print(i," is perfect.")
#Step 9:if (sum_of_factors < i): print(i, " is abundant.")
#Step 10:if (sum_of_factors > i): print(i, " is deficient.")
#Step 11:if( i < n+1) Goto 5
#Step 12: End
#
#TestCases:
#Input:2
#Expected OutPut:
#1  is abundant.
#
#Input:3
#Expected Output:
#1  is abundant.
#2  is abundant.
#
#Write a comment about passing Testing results
#Sucessful
#Program:


n = int(input("Enter a natural number:"))

for i in range(1, n+1):
    sum_of_factors = 0
    for k in range(1,i):
        if (i%k ==0):
            sum_of_factors += k

    if (sum_of_factors == i):
        print(i," is perfect.")
    elif (sum_of_factors < i):
        print(i, " is abundant.")
    elif (sum_of_factors > i):
        print(i, " is deficient.")
