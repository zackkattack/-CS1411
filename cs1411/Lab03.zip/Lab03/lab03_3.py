#Name:Zachary Carson
#Course:CS 1411
#Date:2-19-2017
#
#
#Problem:
#a) Write a program that prompts for an integer—let’s call it X—and then ﬁnds
#the sum of X consecutive integers starting at 1. That is, if X = 5, you will
#ﬁnd the sum of 1 + 2 + 3 + 4 + 5 = 15
#b) Modify your program by enclosing your loop in another loop so that you can
#ﬁnd consecutive sums. For example, if 5 is entered, you will ﬁnd ﬁve sums of
#consecutive numbers:
#1   = 1
#1+2 = 3
#1+2+3 = 6
#1+2+3+4 = 10
#1+2+3+4+5 = 15
#Print only each sum, not the arithmetic expression.
#c) Modify your program again to only print sums if the sum is divisible by the
#number of operands. For example, with the sum 1 + 2 + 3 + 4 + 5 = 15, there are
#ﬁve operands and the sum, 15, is divisible by 5, so that sum will be printed.
#(Do you notice a pattern?)
#
#Given:
#None
#
#
#Analysis
#Input:A integer
#Outputs:The summation of the consecutive numbers of the odd numbers
#leading up to the original number that was entered
#
#
#Method/Algorithm:
#Step 1:Start
#Step 3:Input num
#Step 4:i = 1
#Step 5:k = 1
#Step 6:final_number = 0
#Step 7:final_number += i
#Step 8:if(i < k+1) Goto step 7, i += 1
#Step 9:if(final_number%k = 0) print final_number
#Step 10:if( k < num+1) Goto step 6, k+=1
#Step 2: End
#
#TestCases:
#Input:5
#Expected OutPut:
#1
#6
#15
#
#Input:12
#Expected Output:
#1
#6
#15
#28
#45
#66
#Write a comment about passing Testing results
#Sucessful
#Program:

num = int(input("Enter a number:"))
for k in range(1, num+1):
    final_number = 0
    for i in range(1, k+1):
        final_number += i
    if(final_number% k == 0):
        print(final_number)
