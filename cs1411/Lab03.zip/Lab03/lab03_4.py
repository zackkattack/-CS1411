#Name:Zachary Carson
#Course:CS 1411
#Date:2-19-2017
#
#
#Problem:
#Write a Python program that gets a natural number N and print the value of
#s1, and s2 (using while or for loop, without using any math library).
#
#Given:
#s1 = 1/1^2+1/2^2...+1/n^2
#s2 = summation of factorial of i, i factorial = 1*2*..i
#
#Analysis
#Input:Integer
#Outputs:s1 and s2
#
#
#Method/Algorithm:
#Step 1: Start
#Step 2: Input num
#Step 3: s1 = 0
#Step 4: s2 =0
#Step 5: i = 1
#Step 6: s1 += 1/i*2
#Step 7: if (i < num+1) Goto 6, i+=1
#Step 8: i = 0
#Step 9: fatorial = 1
#Step 10: factorial = factorial*k
#Step 11: if(k < i+1)Goto 10, k +=1
#Step 12: s2 += factorial
#Step 13: if( i < num+1) Goto 9
#Step 14: print s1
#Step 15: pritn s2
#Step 16: End
#
#TestCases:
#Input:5
#Expected OutPut:
#S1 =  1.3611111111111112
#S2 =  10
#
#Input:3
#Expected Output:
#S1 =  1.4636111111111112
#S2 =  154
#Write a comment about passing Testing results
#Sucessful
#Program:

num = int(input("Enter a number:"))

s1 = 0
s2 = 0
for i in range(1,num+1):
    s1 += 1/(i**2)

for i in range(0,num+1):
    factorial = 1
    for k in range(1, i+1):
        factorial = factorial *k
    s2 += factorial

print("S1 = ", s1)
print("S2 = ",s2)
