#Name:Zachary Carson
#Course:CS 1411
#Date:2-15-2017
#
#
#Problem:
#
#Prompt the user for a number
#Print out whether the number is a perfect number
#Prompt the user for another number if the number is not perfect
#
#Given:
#
#None
#
#Analysis
#Input:Any number
#Outputs:
#Weather or not the number that was entered is a perfect number
#
#Method/Algorithm:
#Step 1:Start
#Step 2:Input number
#Step 3:k = 0
#Step 4:i=1
#Step 5:if (number%1 ==0): k = k+1
#Step 6:i = i+1
#Step 7:if(i < number ) Goto 5
#Step 8:if(k == number)print its a perfect number; break
#Step 9:else: its not a perfect numebr; goto step 2
#Step 10:end
#
#
#TestCases:
#Input:4
#Expected OutPut:It is not a perfect number
#prompt the user for a new number
#
#Input:8128
#Expected Output:its a perfect number
#Write a comment about passing Testing results
#Sucessful test
#Program:

while(True):
    number = int(input("Enter a number: "))
    k=0

    for i in range(1,number):
        if(number%i==0):
            k+= i

    if (k == number):
        print ("It is a perfect number")
        break
    else:
        print ("It is not a perfect number")
